#include <GL/glut.h>
#include <cmath>
#include <algorithm>
#include <iostream>

#define PI 3.14159265f

enum Scene { SCHOOL, UNIVERSITY, OFFICE };
Scene currentScene = SCHOOL;

// Animation/State Variables
float uni_timeOfDay = 1.57f;
float sch_studentY = 0.0f;
float sch_studentTimer = 0.0f;
bool sch_studentUp = false;

// --- SHARED DRAWING ALGORITHMS ---

// 3D DDA Line
void drawLineDDA_3D(float x1, float y1, float z1, float x2, float y2, float z2) {
    float dx = x2 - x1, dy = y2 - y1, dz = z2 - z1;
    float steps = std::max(std::abs(dx), std::max(std::abs(dy), std::abs(dz))) * 100.0f;
    if (steps == 0) return;
    float xInc = dx / steps, yInc = dy / steps, zInc = dz / steps;
    float x = x1, y = y1, z = z1;
    glBegin(GL_POINTS);
    for (int i = 0; i <= (int)steps; i++) {
        glVertex3f(x, y, z);
        x += xInc; y += yInc; z += zInc;
    }
    glEnd();
}

// 2D DDA Line (for Office Clock)
void drawLineDDA_2D(float x1, float y1, float x2, float y2) {
    float dx = x2 - x1;
    float dy = y2 - y1;
    float steps = std::abs(dx) > std::abs(dy) ? std::abs(dx) : std::abs(dy);
    if (steps == 0) return;
    float xInc = dx / (float)steps;
    float yInc = dy / (float)steps;
    float x = x1, y = y1;
    glBegin(GL_POINTS);
    for (int i = 0; i <= steps; i++) {
        glVertex2f(x, y);
        x += xInc; y += yInc;
    }
    glEnd();
}

// 3D Midpoint Circle
void drawCircleMidpoint_3D(float x0, float y0, float z, float radius) {
    for (float r = 0; r <= radius; r += 0.01f) {
        int x = 0, y = (int)(r * 100), p = 1 - y;
        glBegin(GL_POINTS);
        while (x <= y) {
            float fx = x / 100.0f, fy = y / 100.0f;
            glVertex3f(x0 + fx, y0 + fy, z); glVertex3f(x0 - fx, y0 + fy, z);
            glVertex3f(x0 + fx, y0 - fy, z); glVertex3f(x0 - fx, y0 - fy, z);
            glVertex3f(x0 + fy, y0 + fx, z); glVertex3f(x0 - fy, y0 + fx, z);
            glVertex3f(x0 + fy, y0 - fx, z); glVertex3f(x0 - fy, y0 - fx, z);
            x++;
            if (p < 0) p += 2 * x + 1;
            else { y--; p += 2 * (x - y) + 1; }
        }
        glEnd();
    }
}

// 2D Midpoint Circle (for Office Clock)
void drawCircleMidPoint_2D(int xc, int yc, int r) {
    int x = 0, y = r;
    int d = 1 - r;
    glBegin(GL_POINTS);
    while (x <= y) {
        glVertex2i(xc + x, yc + y); glVertex2i(xc - x, yc + y);
        glVertex2i(xc + x, yc - y); glVertex2i(xc - x, yc - y);
        glVertex2i(xc + y, yc + x); glVertex2i(xc - y, yc + x);
        glVertex2i(xc + y, yc - x); glVertex2i(xc - y, yc - x);
        if (d < 0) d += 2 * x + 3;
        else { d += 2 * (x - y) + 5; y--; }
        x++;
    }
    glEnd();
}

void drawFilledCircle_2D(int xc, int yc, int r) {
    for (int i = 0; i <= r; i++) {
        drawCircleMidPoint_2D(xc, yc, i);
    }
}

// 3D Midpoint Line
void drawLineMidpoint_3D(float x1, float y1, float z1, float x2, float y2, float z2) {
    float dx = std::abs(x2 - x1), dy = std::abs(y2 - y1), dz = std::abs(z2 - z1);
    float steps = std::max(std::abs(dx), std::max(std::abs(dy), std::abs(dz))) * 100.0f;
    if (steps == 0) return;
    float xInc = (x2 - x1) / steps, yInc = (y2 - y1) / steps, zInc = (z2 - z1) / steps;
    float x = x1, y = y1, z = z1;
    glBegin(GL_POINTS);
    for (int i = 0; i <= (int)steps; i++) {
        glVertex3f(x, y, z);
        x += xInc; y += yInc; z += zInc;
    }
    glEnd();
}

// 2D Midpoint Line
void drawLineMidPoint_2D(int x1, int y1, int x2, int y2) {
    int dx = std::abs(x2 - x1);
    int dy = std::abs(y2 - y1);
    int sx = (x1 < x2) ? 1 : -1;
    int sy = (y1 < y2) ? 1 : -1;
    int err = dx - dy;
    glBegin(GL_POINTS);
    while (true) {
        glVertex2i(x1, y1);
        if (x1 == x2 && y1 == y2) break;
        int e2 = 2 * err;
        if (e2 > -dy) { err -= dy; x1 += sx; }
        if (e2 < dx) { err += dx; y1 += sy; }
    }
    glEnd();
}

// Generic Box/Cube Helper
void drawBox(float x, float y, float z, float w, float h, float d) {
    glPushMatrix();
    glTranslatef(x + w / 2.0f, y + h / 2.0f, z + d / 2.0f);
    glScalef(w, h, d);
    glutSolidCube(1.0);
    glPopMatrix();
}

// Office specific cube helper with materials
void drawSolidCube_Office(float x, float y, float z,
                   float sx, float sy, float sz,
                   float r, float g, float b, float a = 1.0f) {
    GLfloat mat_diffuse[] = { r, g, b, a };
    GLfloat mat_specular[] = { 0.3f, 0.3f, 0.3f, 1.0f };
    GLfloat shininess[] = { 20.0f };
    glMaterialfv(GL_FRONT, GL_DIFFUSE, mat_diffuse);
    glMaterialfv(GL_FRONT, GL_SPECULAR, mat_specular);
    glMaterialfv(GL_FRONT, GL_SHININESS, shininess);
    glPushMatrix();
    glTranslatef(x, y, z);
    glScalef(sx, sy, sz);
    glutSolidCube(1.0);
    glPopMatrix();
}


// --- UNIVERSITY (main.cpp) DATA & FUNCTIONS ---


static void drawUniOutdoor() {
    float s = (sin(uni_timeOfDay) + 1.0f) * 0.5f;
    glDisable(GL_LIGHTING);
    glBegin(GL_QUADS);
    glColor3f(0.24f * s, 0.54f * s, 0.90f * s); glVertex3f(-8.4f, 8.0f, -13.0f); glVertex3f(-8.4f, 8.0f, 15.0f);
    glColor3f(0.62f * s, 0.84f * s, 0.98f * s); glVertex3f(-8.4f, 3.4f, 15.0f); glVertex3f(-8.4f, 3.4f, -13.0f);
    glEnd();
    glBegin(GL_QUADS);
    glColor3f(0.35f * s, 0.62f * s, 0.24f * s); glVertex3f(-8.4f, 3.4f, -13.0f); glVertex3f(-8.4f, 3.4f, 15.0f);
    glColor3f(0.20f * s, 0.44f * s, 0.15f * s); glVertex3f(-8.4f, 0.0f, 15.0f); glVertex3f(-8.4f, 0.0f, -13.0f);
    glEnd();
    glPushMatrix();
    glTranslatef(-12.5f, 3.8f, 0.0f);
    glColor3f(0.68f * s, 0.75f * s, 0.87f * s); glutSolidSphere(3.2f, 36, 28);
    glPopMatrix();
    glEnable(GL_LIGHTING);
}

static void drawUniRightOutdoor() {
    float s = (sin(uni_timeOfDay) + 1.0f) * 0.5f;
    glDisable(GL_LIGHTING);
    glBegin(GL_QUADS);
    glColor3f(0.30f * s, 0.60f * s, 0.95f * s); glVertex3f(10.9f, 8.0f, -13.0f); glVertex3f(10.9f, 8.0f, 15.0f);
    glColor3f(0.68f * s, 0.88f * s, 1.00f * s); glVertex3f(10.9f, 3.2f, 15.0f); glVertex3f(10.9f, 3.2f, -13.0f);
    glEnd();
    glBegin(GL_QUADS);
    glColor3f(0.38f * s, 0.65f * s, 0.25f * s); glVertex3f(10.9f, 3.2f, -13.0f); glVertex3f(10.9f, 3.2f, 15.0f);
    glColor3f(0.22f * s, 0.46f * s, 0.16f * s); glVertex3f(10.9f, 0.0f, 15.0f); glVertex3f(10.9f, 0.0f, -13.0f);
    glEnd();
    glEnable(GL_LIGHTING);
}

static void drawUniSun(float x, float y, float z, float r) {
    glDisable(GL_LIGHTING);
    glColor3f(1.0f, 1.0f, 0.0f);
    glPushMatrix();
    glTranslatef(x, y, z);
    glutSolidSphere(r, 20, 20);
    glPopMatrix();
    glEnable(GL_LIGHTING);
}

static void drawUniBackOutdoor() {
    float s = (sin(uni_timeOfDay) + 1.0f) * 0.5f;
    glDisable(GL_LIGHTING);
    glBegin(GL_QUADS);
    glColor3f(0.2f * s, 0.4f * s, 0.8f * s); glVertex3f(-12, 10, -13.4f); glVertex3f(12, 10, -13.4f);
    glColor3f(0.6f * s, 0.8f * s, 1.0f * s); glVertex3f(12, 3, -13.4f); glVertex3f(-12, 3, -13.4f);
    glEnd();
    if (s > 0.15f) drawUniSun(1.0f, 2.0f + 3.5f * s, -13.25f, 0.8f);
    glBegin(GL_QUADS);
    glColor3f(0.1f * s, 0.4f * s, 0.1f * s); glVertex3f(-12, 3, -13.4f); glVertex3f(12, 3, -13.4f);
    glColor3f(0.0f, 0.2f * s, 0.0f); glVertex3f(12, 0, -13.4f); glVertex3f(-12, 0, -13.4f);
    glEnd();
    glEnable(GL_LIGHTING);
}

static void drawUniFloor() {
    glDisable(GL_LIGHTING);
    for (int i = 0; i < 12; i++) {
        for (int j = 0; j < 14; j++) {
            bool light = (i + j) % 2 == 0;
            glColor3f(light ? 0.91f : 0.83f, light ? 0.89f : 0.81f, light ? 0.86f : 0.78f);
            float x0 = -8.0f + i * 1.541f + 0.02f, z0 = -13.0f + j * 1.643f + 0.02f;
            drawBox(x0, 0.01f, z0, 1.5f, 0.01f, 1.6f);
        }
    }
    glEnable(GL_LIGHTING);
}

static void drawUniCeiling() {
    glColor3f(0.93f, 0.93f, 0.95f);
    drawBox(-8.0f, 7.0f, -13.0f, 18.5f, 0.1f, 23.0f);
}

static void drawUniLeftWall() {
    float s = (sin(uni_timeOfDay) + 1.0f) * 0.5f;
    glColor3f(0.87f, 0.87f, 0.91f);
    drawBox(-8.0f, 6.45f, -13.0f, 0.15f, 0.55f, 23.0f);
    drawBox(-8.0f, 0.0f, -13.0f, 0.15f, 1.10f, 23.0f);
    float wC[] = {8.8f, 6.0f, 3.1f, 0.1f, -2.9f, -5.9f, -8.8f};
    for(int i=0; i<7; i++) drawBox(-8.0f, 1.1f, wC[i]-0.15f, 0.15f, 5.35f, 0.3f);
    glEnable(GL_BLEND); glDisable(GL_LIGHTING); glColor4f(0.68f * s, 0.84f * s, 1.00f * s, 0.12f);
    drawBox(-8.05f, 1.1f, -13.0f, 0.01f, 5.35f, 23.0f);
    glDisable(GL_BLEND); glEnable(GL_LIGHTING);
}

static void drawUniWalls() {
    float s = (sin(uni_timeOfDay) + 1.0f) * 0.5f;
    glColor3f(0.87f, 0.87f, 0.91f);
    drawBox(10.5f, 6.2f, -13.0f, 0.15f, 0.8f, 23.0f);
    drawBox(10.5f, 0.0f, -13.0f, 0.15f, 1.2f, 23.0f);
    float RWZ[] = {7.5f, 4.5f, 1.5f, -1.5f, -4.5f, -7.5f, -10.5f};
    for(int i=0; i<7; i++) drawBox(10.5f, 1.2f, RWZ[i]-0.3f, 0.15f, 5.0f, 0.6f);
    glEnable(GL_BLEND); glDisable(GL_LIGHTING); glColor4f(0.68f * s, 0.84f * s, 1.00f * s, 0.12f);
    drawBox(10.55f, 1.2f, -13.0f, 0.01f, 5.0f, 23.0f);
    glDisable(GL_BLEND); glEnable(GL_LIGHTING);
}

static void drawUniBackWall() {
    float s = (sin(uni_timeOfDay) + 1.0f) * 0.5f;
    glColor3f(0.87f, 0.87f, 0.91f);
    drawBox(-8.0f, 6.7f, -13.0f, 18.5f, 0.3f, 0.3f);
    drawBox(-8.0f, 0.0f, -13.0f, 18.5f, 0.3f, 0.3f);
    drawBox(-8.0f, 0.0f, -13.0f, 0.3f, 7.0f, 0.3f);
    drawBox(10.2f, 0.0f, -13.0f, 0.3f, 7.0f, 0.3f);
    glEnable(GL_BLEND); glDisable(GL_LIGHTING); glColor4f(0.68f * s, 0.84f * s, 1.00f * s, 0.09f);
    drawBox(-8.0f, 0.0f, -12.94f, 18.5f, 7.0f, 0.01f);
    glDisable(GL_BLEND); glEnable(GL_LIGHTING);
}

static void drawUniAC(float x, float y, float z) {
    glColor3f(0.91f, 0.91f, 0.93f); drawBox(x - 1.75f, y - 0.28f, z - 0.475f, 3.5f, 0.28f, 0.95f);
}

static void drawUniProjector(float x, float y, float z) {
    glColor3f(0.50f, 0.50f, 0.52f); drawBox(x - 0.03f, y - 0.32f, z - 0.03f, 0.06f, 0.32f, 0.06f);
    glColor3f(0.18f, 0.18f, 0.20f); drawBox(x - 0.26f, y - 0.65f, z - 0.18f, 0.52f, 0.20f, 0.36f);
}

static void drawUniArmChair(float x, float y, float z) {
    glPushMatrix(); glTranslatef(x, y, z);
    glColor3f(0.14f, 0.14f, 0.16f);
    drawBox(-0.3585f, 0.0f, -0.3585f, 0.057f, 1.10f, 0.057f);
    drawBox( 0.3015f, 0.0f, -0.3585f, 0.057f, 1.10f, 0.057f);
    drawBox(-0.3585f, 0.0f,  0.3015f, 0.057f, 1.10f, 0.057f);
    drawBox( 0.3015f, 0.0f,  0.3015f, 0.057f, 1.10f, 0.057f);
    glColor3f(0.15f, 0.15f, 0.17f); drawBox(-0.33f, 1.10f, -0.325f, 0.66f, 0.08f, 0.65f);
    glPushMatrix(); glTranslatef(0.0f, 1.60f, -0.28f); glRotatef(-4.0f, 1.0f, 0.0f, 0.0f); drawBox(-0.325f, -0.4f, -0.035f, 0.65f, 0.80f, 0.07f); glPopMatrix();
    glColor3f(0.14f, 0.14f, 0.16f); drawBox(0.33f, 1.34f, -0.33f, 0.07f, 0.10f, 0.66f);
    glColor3f(0.48f, 0.38f, 0.28f); drawBox(0.31f, 1.44f, -0.38f, 0.45f, 0.05f, 1.15f);
    glPopMatrix();
}

static void drawUniBook(float x, float y, float z, float rotY, float r, float g, float b) {
    glPushMatrix(); glTranslatef(x, y, z); glRotatef(rotY, 0.0f, 1.0f, 0.0f);
    glColor3f(r, g, b); drawBox(-0.22f, -0.0275f, -0.3f, 0.44f, 0.055f, 0.60f);
    glColor3f(0.96f, 0.96f, 0.92f); drawBox(-0.2f, -0.02f, 0.2975f, 0.40f, 0.040f, 0.015f);
    glPopMatrix();
}

static void drawUniStudent(float x, float y, float z, float sR, float sG, float sB, float pR, float pG, float pB, float kR, float kG, float kB) {
    glPushMatrix(); glTranslatef(x, y, z);
    glColor3f(pR, pG, pB); drawBox(-0.35f, 0.0f, -0.15f, 0.3f, 1.6f, 0.3f); drawBox(0.05f, 0.0f, -0.15f, 0.3f, 1.6f, 0.3f);
    glColor3f(sR, sG, sB); drawBox(-0.36f, 1.55f, -0.22f, 0.72f, 0.95f, 0.43f);
    glColor3f(kR, kG, kB); drawBox(-0.085f, 2.45f, -0.085f, 0.17f, 0.22f, 0.17f);
    glPushMatrix(); glTranslatef(0.0f, 2.95f, 0.0f); glRotatef(20.0f, 1.0f, 0.0f, 0.0f); glutSolidSphere(0.3f, 16, 12); glPopMatrix();
    glPopMatrix();
}

void displayUniversity() {
    glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
    glEnable(GL_LIGHTING);
    glEnable(GL_LIGHT0);
    glEnable(GL_COLOR_MATERIAL);

    gluLookAt(-5.2, 4.9, 9.8, 3.8, 2.4, -7.5, 0, 1, 0);

    // Set University Light Position
    GLfloat pos[] = {2.0f, 6.5f, 0.0f, 1.0f};
    glLightfv(GL_LIGHT0, GL_POSITION, pos);

    float s = (sin(uni_timeOfDay) + 1.0f) * 0.5f;
    GLfloat amb[] = {0.2f * s, 0.2f * s, 0.2f * s, 1.0f};
    GLfloat dif[] = {0.7f * s, 0.7f * s, 0.7f * s, 1.0f};
    glLightfv(GL_LIGHT0, GL_AMBIENT, amb); glLightfv(GL_LIGHT0, GL_DIFFUSE, dif);

    drawUniOutdoor(); drawUniRightOutdoor(); drawUniBackOutdoor();
    drawUniFloor(); drawUniCeiling(); drawUniWalls(); drawUniLeftWall(); drawUniBackWall();
    drawUniAC(2.0f, 7.0f, -1.0f); drawUniProjector(8.5f, 7.0f, 2.8f);
    static const float rowZ[] = {5.0f, 2.5f, 0.0f, -2.5f, -5.0f, -7.5f};
    static const float colX[] = {-3.5f, 0.5f, 4.0f, 7.5f};
    for (int r = 0; r < 4; r++) {
        for (int c = 0; c < 4; c++) {
            if (r == 1 && (c == 0 || c == 1)) continue;
            drawUniArmChair(colX[c], 0.0f, rowZ[r]);
        }
        drawUniArmChair(colX[3] + 3.2f, 0.0f, rowZ[r]);
    }
    drawUniArmChair(colX[0], 0.0f, rowZ[1]); drawUniArmChair(colX[1], 0.0f, rowZ[1]);
    drawUniBook(colX[0]+0.35f, 1.4f, rowZ[1]-0.2f, 10, 0.12f, 0.18f, 0.52f);
    drawUniBook(colX[1]+0.38f, 1.4f, rowZ[1]-0.18f, -8, 0.1f, 0.16f, 0.5f);
    drawUniStudent(colX[0], 0.0f, rowZ[1]+0.85f, 0.34f, 0.4f, 0.23f, 0.18f, 0.18f, 0.22f, 0.88f, 0.73f, 0.59f);
    drawUniStudent(colX[1], 0.0f, rowZ[1]+0.85f, 0.11f, 0.17f, 0.44f, 0.42f, 0.34f, 0.28f, 0.76f, 0.6f, 0.47f);
    glColor3f(0.28f, 0.27f, 0.3f); drawBox(colX[0]-1.425f, 0.0f, rowZ[1]+0.51f, 0.55f, 0.84f, 0.38f);
}


// --- OFFICE (office.cpp) DATA & FUNCTIONS ---
float off_fanAngle = 0.0f;
bool off_lightOn = true;
float off_visitorX = -11.5f;
float off_visitorZ = -2.0f;
float off_doorAngle = 0.0f;
bool off_doorOpened = false;
bool off_doorClosed = false;
float off_watchAngle = 0.0f;
bool off_isReturning = false;

void drawOfficeInterior() {
    drawSolidCube_Office(0, -1.0, 0, 24, 0.1, 30, 0.55f, 0.55f, 0.55f);
    drawSolidCube_Office(0, 9.0, 0, 24, 0.1, 30, 0.9f, 0.9f, 0.9f);
    drawSolidCube_Office(0, 8.9, 5, 4, 0.1, 4, 1.0f, 1.0f, 0.8f);
    drawSolidCube_Office(12, 4, 0, 0.2, 10, 30, 0.75f, 0.75f, 0.75f);
    drawSolidCube_Office(-12, 4, 0, 0.2, 10, 30, 0.75f, 0.75f, 0.75f);
    drawSolidCube_Office(0, 4, 15, 24, 10, 0.2, 0.8f, 0.8f, 0.8f);
    glEnable(GL_BLEND); glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    drawSolidCube_Office(0, 4, -15, 24, 10, 0.1, 0.4f, 0.7f, 0.9f, 0.3f);
    glDisable(GL_BLEND);
    drawSolidCube_Office(0, 4, -14.9, 0.2, 10, 0.2, 0.1f, 0.1f, 0.1f);
    drawSolidCube_Office(0, 4, -14.9, 24, 0.2, 0.2, 0.1f, 0.1f, 0.1f);
    drawSolidCube_Office(0, 8.5, 5, 0.2, 1.0, 0.2, 0.2f, 0.2f, 0.2f);
    drawSolidCube_Office(0, 8.0, 5, 1.2, 0.4, 1.2, 0.3f, 0.3f, 0.3f);
    for (int i = 0; i < 3; i++) {
        glPushMatrix();
        glTranslatef(0, 8.0, 5);
        glRotatef(off_fanAngle + (i * 120.0f), 0, 1, 0);
        glTranslatef(2.5, 0, 0);
        drawSolidCube_Office(0, 0, 0, 4.0, 0.1, 0.8, 0.15f, 0.15f, 0.15f);
        glPopMatrix();
    }
    glPushMatrix();
    glTranslatef(-11.9, 2.5, -4.0);
    glRotatef(off_doorAngle, 0, 1, 0);
    glTranslatef(0, 0, 2.0);
    drawSolidCube_Office(0, 0, 0, 0.1, 7, 4, 0.4f, 0.25f, 0.1f);
    drawSolidCube_Office(0.1, 0, 1.5, 0.05, 1.0, 0.4, 0.6f, 0.6f, 0.6f);
    drawSolidCube_Office(0.2, 0.1, 1.5, 0.2, 0.15, 0.8, 0.2f, 0.2f, 0.2f);
    glPopMatrix();
    drawSolidCube_Office(9.0, 3.0, -13.5, 3.0, 8.0, 2.0, 1.0f, 0.85f, 0.0f);
    drawSolidCube_Office(9.0, 3.0, -12.4, 2.8, 7.8, 0.1, 0.9f, 0.75f, 0.0f);
    drawSolidCube_Office(8.0, 3.5, -12.3, 0.2, 0.8, 0.2, 0.1f, 0.1f, 0.1f);
    drawSolidCube_Office(0, 0, -5, 10, 0.4, 5, 0.5f, 0.3f, 0.15f);
    drawSolidCube_Office(0, -0.6, 1, 2.5, 0.3, 2.5, 0.15f, 0.15f, 0.15f);
    drawSolidCube_Office(0, 1.2, 2.2, 2.5, 3.5, 0.4, 0.25f, 0.25f, 0.25f);
    GLfloat skin_color[] = { 0.8f, 0.7f, 0.6f, 1.0f };
    GLfloat hair_color[] = { 0.15f, 0.1f, 0.05f, 1.0f };
    drawSolidCube_Office(0, 1.5, 0.5, 1.2, 2.2, 0.8, 0.2f, 0.3f, 0.6f);
    drawSolidCube_Office(-0.3, 0.1, 0.5, 0.4, 1.0, 0.4, 0.1f, 0.1f, 0.3f);
    drawSolidCube_Office(0.3, 0.1, 0.5, 0.4, 1.0, 0.4, 0.1f, 0.1f, 0.3f);
    glPushMatrix();
    glTranslatef(0, 3.1, 0.5);
    glMaterialfv(GL_FRONT, GL_DIFFUSE, skin_color);
    glutSolidSphere(0.6, 40, 40);
    glMaterialfv(GL_FRONT, GL_DIFFUSE, hair_color);
    glTranslatef(0, 0.3, 0); glScalef(1.1, 0.5, 1.1); glutSolidCube(1.0);
    glPopMatrix();
    drawSolidCube_Office(off_visitorX, 1.8, off_visitorZ, 1.1, 2.4, 0.7, 0.5f, 0.2f, 0.2f);
    drawSolidCube_Office(off_visitorX - 0.25, 0.3, off_visitorZ, 0.35, 1.2, 0.35, 0.2f, 0.1f, 0.1f);
    drawSolidCube_Office(off_visitorX + 0.25, 0.3, off_visitorZ, 0.35, 1.2, 0.35, 0.2f, 0.1f, 0.1f);
    glPushMatrix();
    glTranslatef(off_visitorX, 3.5, off_visitorZ);
    glMaterialfv(GL_FRONT, GL_DIFFUSE, skin_color);
    glutSolidSphere(0.55, 40, 40);
    glMaterialfv(GL_FRONT, GL_DIFFUSE, hair_color);
    glTranslatef(0, 0.35, 0.1); glScalef(1.0, 0.4, 0.9); glutSolidCube(1.0);
    glPopMatrix();
    drawSolidCube_Office(0, 0.4, -5, 3.0, 0.1, 2.2, 0.05f, 0.05f, 0.05f);
    drawSolidCube_Office(3.0, 0.5, -3.5, 0.5, 0.8, 0.5, 0.1f, 0.1f, 0.1f);
    drawSolidCube_Office(-3.5, 0.35, -4.5, 1.8, 0.3, 1.2, 0.6f, 0.1f, 0.1f);
    drawSolidCube_Office(-3.5, 0.65, -4.5, 1.8, 0.3, 1.2, 0.1f, 0.4f, 0.2f);
    drawSolidCube_Office(4.0, 0.3, -6.0, 1.0, 0.2, 1.0, 0.2f, 0.2f, 0.2f);
    drawSolidCube_Office(4.0, 1.3, -6.0, 0.1, 2.0, 0.1, 0.3f, 0.3f, 0.3f);
    glPushMatrix();
    glTranslatef(4.0, 2.3, -6.0); glRotatef(-45, 1, 0, 0); drawSolidCube_Office(0, 0, 0, 0.8, 0.6, 1.2, 0.8f, 0.2f, 0.2f);
    glPopMatrix();

    glDisable(GL_LIGHTING);
    glPushMatrix();
    glTranslatef(0.0, 6.0, -14.8); glScalef(0.02, 0.02, 0.02);
    glColor3f(1.0f, 1.0f, 1.0f); drawFilledCircle_2D(0, 0, 50);
    glColor3f(0.0f, 0.0f, 0.0f); drawCircleMidPoint_2D(0, 0, 50);
    glPopMatrix();
    glPushMatrix();
    glTranslatef(0.0, 6.0, -14.7); glScalef(0.02, 0.02, 0.02); glRotatef(off_watchAngle, 0, 0, 1);
    glColor3f(0.0f, 0.0f, 1.0f); drawLineDDA_2D(0, 0, 0, 40);
    glPopMatrix();
    glPushMatrix();
    glTranslatef(0.0, 6.0, -14.7); glScalef(0.02, 0.02, 0.02); glRotatef(off_watchAngle * 0.1, 0, 0, 1);
    glColor3f(1.0f, 0.0f, 0.0f); drawLineMidPoint_2D(0, 0, 25, 0);
    glPopMatrix();

    glPushMatrix();
    glBegin(GL_QUADS);
    glColor3f(1.0f, 0.0f, 0.0f); glVertex3f(-11.9f, -0.9f, 14.5f);
    glColor3f(0.0f, 1.0f, 0.0f); glVertex3f(-2.0f, -0.9f, 14.5f);
    glColor3f(0.0f, 0.0f, 1.0f); glVertex3f(-2.0f, 7.0f, 14.5f);
    glColor3f(1.0f, 1.0f, 0.0f); glVertex3f(-11.9f, 7.0f, 14.5f);
    glEnd();
    glPopMatrix();
    glEnable(GL_LIGHTING);
}

void displayOffice() {
    glClearColor(0.05f, 0.05f, 0.1f, 1.0f);
    glEnable(GL_LIGHTING);
    glEnable(GL_LIGHT0);
    glDisable(GL_COLOR_MATERIAL); // Office uses explicit materials

    // Reset light to static values for Office
    GLfloat ambient[] = { 0.4f, 0.4f, 0.4f, 1.0f };
    GLfloat diffuse[] = { 1.0f, 1.0f, 1.0f, 1.0f };
    glLightfv(GL_LIGHT0, GL_AMBIENT, ambient);
    glLightfv(GL_LIGHT0, GL_DIFFUSE, diffuse);

    gluLookAt(0.0, 6.0, 14.5, 0.0, 3.0, -5.0, 0.0, 1.0, 0.0);
    GLfloat light_pos[] = { 0.0f, 8.0f, 5.0f, 1.0f };
    glLightfv(GL_LIGHT0, GL_POSITION, light_pos);
    drawOfficeInterior();
}


// --- SCHOOL (school.cpp) DATA & FUNCTIONS ---
float sch_fanAngle = 0.0f;
float sch_teacherX = 7.5f;
float sch_teacherspeed = 0.02f; // Increased for better visibility in unified loop

void drawSchStudent(float x, float y, float z, float r, float g, float b) {
    glPushMatrix(); glTranslatef(x, y, z);
    glColor3f(r, g, b); drawBox(-0.4, 0, -0.2, 0.8, 1.2, 0.4);
    glColor3f(0.9, 0.7, 0.6); drawCircleMidpoint_3D(0, 1.5, 0, 0.3);
    glColor3f(0.1, 0.1, 0.1); drawBox(-0.3, 1.65, -0.2, 0.6, 0.2, 0.4);
    glPopMatrix();
}

void drawSchTeacher(float xPos) {
    glPushMatrix(); glTranslatef(xPos, 1.0, -7.5);
    glColor3f(0.1, 0.1, 0.4); drawBox(-0.5, 0, -0.3, 1, 1.6, 0.6);
    glColor3f(0.0, 0.0, 0.2); drawBox(-0.4, -1.0, -0.2, 0.3, 1.0, 0.4); drawBox(0.1, -1.0, -0.2, 0.3, 1.0, 0.4);
    glColor3f(0.9, 0.7, 0.6); drawCircleMidpoint_3D(0, 1.9, 0, 0.35);
    glColor3f(0.05, 0.05, 0.05); drawBox(-0.35, 2.1, -0.25, 0.7, 0.2, 0.5);
    glPopMatrix();
}

void drawSchFan(float x, float y, float z) {
    glPushMatrix(); glTranslatef(x, y, z);
    glColor3f(0.1, 0.1, 0.1); drawBox(-0.05, 0, -0.05, 0.1, 1.0, 0.1);
    glRotatef(sch_fanAngle, 0, 1, 0);
    for (int i = 0; i < 4; i++) {
        glRotatef(90, 0, 1, 0);
        glColor3f(0.3, 0.3, 0.3); drawBox(0.2, -0.08, -0.15, 1.8, 0.05, 0.3);
    }
    glPopMatrix();
}

void displaySchool() {
    glClearColor(0.1f, 0.1f, 0.1f, 1.0f);
    gluLookAt(7.5, 4.5, 22.0, 7.5, 3.2, 0.0, 0.0, 1.0, 0.0);
    glDisable(GL_LIGHTING); // School scene doesn't use lighting
    glColor3f(0.8, 0.8, 0.8); drawBox(0, -0.1, -10, 15, 0.1, 30);
    glColor3f(0.95, 0.95, 0.95); drawBox(0, 10, -10, 15, 0.2, 30);
    glColor3f(0.85, 0.85, 0.8); drawBox(0, 0, -10, 0.1, 10, 5); drawBox(0, 0, 5, 0.1, 10, 15); drawBox(0, 0, -5, 0.1, 3.5, 10); drawBox(0, 7.5, -5, 0.1, 2.5, 10);
    glPointSize(4.0); glColor3f(0.0, 0.0, 0.0);
    drawLineDDA_3D(0.1, 3.5, -5.0, 0.1, 7.5, -5.0); drawLineDDA_3D(0.1, 3.5, 5.0, 0.1, 7.5, 5.0);
    drawLineDDA_3D(0.1, 3.5, -5.0, 0.1, 3.5, 5.0); drawLineDDA_3D(0.1, 7.5, -5.0, 0.1, 7.5, 5.0);
    drawLineDDA_3D(0.1, 3.5, 0.0, 0.1, 7.5, 0.0);
    glEnable(GL_BLEND); glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    glColor4f(0.6, 0.8, 1.0, 0.3); drawBox(0.05, 3.5, -5.0, 0.02, 4.0, 10.0);
    glDisable(GL_BLEND);
    glColor3f(0.85, 0.85, 0.8); drawBox(14.9, 0, -10, 0.1, 10, 15); drawBox(14.9, 0, 10, 0.1, 10, 10); drawBox(14.9, 7.5, 5, 0.1, 2.5, 5);
    glColor3f(0.2, 0.1, 0.0); glPointSize(4.0);
    drawLineMidpoint_3D(14.88, 0.0, 5.0, 14.88, 7.5, 5.0); drawLineMidpoint_3D(14.88, 0.0, 10.0, 14.88, 7.5, 10.0); drawLineMidpoint_3D(14.88, 7.5, 5.0, 14.88, 7.5, 10.0);
    glColor3f(0.4, 0.2, 0.1); drawBox(14.85, 0, 5, 0.03, 7.5, 5.0);
    glColor3f(1.0, 1.0, 0.0); drawBox(14.8, 3.2, 9.3, 0.1, 0.8, 0.5);
    glColor3f(0.9, 0.9, 0.9); drawBox(0, 0, -10, 15, 10, 0.1);
    glColor3f(1.0, 1.0, 1.0); drawBox(4.5, 3.8, -9.8, 6.0, 3.5, 0.05);
    drawSchTeacher(sch_teacherX);
    drawSchFan(4, 10, 0); drawSchFan(11, 10, 0); drawSchFan(7.5, 10, 8);
    for (int i = 0; i < 2; i++) {
        float z = 3 + i * 5;
        glColor3f(0.5, 0.3, 0.1); drawBox(3.5, 1.8, z, 8, 0.2, 1.5);
        glColor3f(0.6, 0.4, 0.2); drawBox(3.5, 0.8, z + 2.5, 8, 0.2, 0.8);
        // Apply slow movement to students
        drawSchStudent(5.5, 1.0f + sch_studentY, z + 2.7, 0.7, 0.1, 0.1); 
        drawSchStudent(9.5, 1.0f + sch_studentY, z + 2.7, 0.1, 0.6, 0.1);
    }
}


// --- MAIN FRAMEWORK ---

void setupProjection(int w, int h) {
    if (h == 0) h = 1;
    glViewport(0, 0, w, h);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    switch (currentScene) {
        case SCHOOL:     gluPerspective(55.0, (double)w/h, 1.0, 100.0); break;
        case UNIVERSITY: gluPerspective(48.0, (double)w/h, 0.4, 130.0); break;
        case OFFICE:     gluPerspective(60.0, (double)w/h, 0.1, 100.0); break;
    }
    glMatrixMode(GL_MODELVIEW);
}

void display() {
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    glLoadIdentity();
    
    switch (currentScene) {
        case SCHOOL:     displaySchool();     break;
        case UNIVERSITY: displayUniversity(); break;
        case OFFICE:     displayOffice();     break;
    }
    glutSwapBuffers();
}

void reshape(int w, int h) {
    setupProjection(w, h);
}

void keyboard(unsigned char key, int x, int y) {
    switch (key) {
        case 's': case 'S':
            currentScene = SCHOOL;
            setupProjection(glutGet(GLUT_WINDOW_WIDTH), glutGet(GLUT_WINDOW_HEIGHT));
            break;
        case 'u': case 'U':
            currentScene = UNIVERSITY;
            setupProjection(glutGet(GLUT_WINDOW_WIDTH), glutGet(GLUT_WINDOW_HEIGHT));
            break;
        case 'o': case 'O':
            currentScene = OFFICE;
            // Reset office animation state on switch
            off_visitorX = -11.5f; off_visitorZ = -2.0f;
            off_doorAngle = 0.0f; off_doorOpened = false; off_doorClosed = false;
            off_isReturning = false;
            setupProjection(glutGet(GLUT_WINDOW_WIDTH), glutGet(GLUT_WINDOW_HEIGHT));
            break;
        case 27: exit(0); break;
        
        // Office specific keyboard inputs
        case '1':
            if (currentScene == OFFICE) {
                if (off_doorClosed && off_visitorX >= -2.0f) {
                    off_isReturning = true;
                    off_doorClosed = false;
                }
            }
            break;
        case '2':
            if (currentScene == OFFICE) {
                off_lightOn = !off_lightOn;
                if (off_lightOn) glEnable(GL_LIGHT0); else glDisable(GL_LIGHT0);
            }
            break;
    }
    glutPostRedisplay();
}

void idle() {
    static int lastTime = 0;
    int currentTime = glutGet(GLUT_ELAPSED_TIME);
    if (lastTime == 0) lastTime = currentTime;
    float deltaTime = (currentTime - lastTime) / 1000.0f;
    lastTime = currentTime;

    // University: Sun speed increased
    uni_timeOfDay += 0.4f * deltaTime; 
    if (uni_timeOfDay > 2 * PI) uni_timeOfDay -= 2 * PI;

    // School: Slow student movement added
    sch_studentTimer += deltaTime;
    if (sch_studentTimer > 3.0f) { // Toggle every 3 seconds (slow)
        sch_studentTimer = 0;
        sch_studentUp = !sch_studentUp;
    }
    if (sch_studentUp) sch_studentY += 0.2f * deltaTime; else sch_studentY -= 0.2f * deltaTime;
    if (sch_studentY > 0.3f) sch_studentY = 0.3f;
    if (sch_studentY < 0.0f) sch_studentY = 0.0f;

    sch_fanAngle += 200.0f * deltaTime;
    sch_teacherX += sch_teacherspeed * 15.0f * deltaTime; 
    if (sch_teacherX > 9.5f || sch_teacherX < 5.5f) sch_teacherspeed *= -1;

    // Office: Man movement speed increased
    off_fanAngle += 500.0f * deltaTime;
    if (off_fanAngle > 360) off_fanAngle -= 360;

    if (!off_isReturning) {
        if (!off_doorOpened) {
            if (off_doorAngle > -90.0f) off_doorAngle -= 100.0f * deltaTime; // Faster door
            else off_doorOpened = true;
        } else if (off_doorOpened && !off_doorClosed) {
            if (off_visitorX < -9.5f) off_visitorX += 5.0f * deltaTime; // Faster visitor
            else {
                if (off_doorAngle < 0.0f) off_doorAngle += 100.0f * deltaTime;
                else off_doorClosed = true;
            }
        } else if (off_doorClosed) {
            if (off_visitorZ > -9.0f) off_visitorZ -= 5.0f * deltaTime;
            else if (off_visitorX < -2.0f) off_visitorX += 5.0f * deltaTime;
        }
    } else {
        if (off_visitorX > -9.5f && off_visitorZ <= -9.0f) off_visitorX -= 5.0f * deltaTime;
        else if (off_visitorZ < -2.0f) off_visitorZ += 5.0f * deltaTime;
        else if (off_doorAngle > -90.0f && off_visitorX > -12.0f) off_doorAngle -= 100.0f * deltaTime;
        else if (off_visitorX > -12.5f) off_visitorX -= 5.0f * deltaTime;
        else if (off_doorAngle < 0.0f) {
            off_doorAngle += 100.0f * deltaTime;
            if(off_doorAngle > 0.0f) off_doorAngle = 0.0f;
        }
    }
    off_watchAngle -= 40.0f * deltaTime;

    glutPostRedisplay();
}

void init() {
    glEnable(GL_DEPTH_TEST);
    glEnable(GL_LIGHTING);
    glEnable(GL_LIGHT0);
    glEnable(GL_COLOR_MATERIAL);
    glEnable(GL_NORMALIZE);
    glShadeModel(GL_SMOOTH);
    
    // Default light settings (shared or updated per scene)
    GLfloat ambient[] = { 0.4f, 0.4f, 0.4f, 1.0f };
    GLfloat diffuse[] = { 1.0f, 1.0f, 1.0f, 1.0f };
    glLightfv(GL_LIGHT0, GL_AMBIENT, ambient);
    glLightfv(GL_LIGHT0, GL_DIFFUSE, diffuse);
    
    glClearColor(0.05f, 0.05f, 0.1f, 1.0f);
}

int main(int argc, char** argv) {
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
    glutInitWindowSize(1200, 800);
    glutCreateWindow("Scene Switcher: S-School, U-University, O-Office");
    init();
    glutDisplayFunc(display);
    glutReshapeFunc(reshape);
    glutKeyboardFunc(keyboard);
    glutIdleFunc(idle);
    glutMainLoop();
    return 0;
}
